#!/usr/bin/env python3
"""Build data/journal_index.json from the OFFICIAL Scopus and Web of Science lists.

Inputs (download these yourself — see data/README.md):

  --scopus  Scopus Source Title List (.xlsx or .csv) from Elsevier.
            Every sheet is read. Sheets whose name contains "discontinued"
            are treated as the Scopus *Discontinued Sources* list.
  --wos     One or more Clarivate Master Journal List collection downloads
            (.csv or .xlsx), given as INDEX=PATH, e.g.
              --wos SCIE=data/raw/wos-core_SCIE.csv --wos ESCI=data/raw/wos-core_ESCI.csv
            If INDEX= is omitted it is guessed from the filename (SCIE/SSCI/AHCI/ESCI).

Example:
  python scripts/build_index.py \
      --scopus data/raw/ext_list_October_2026.xlsx \
      --wos SCIE=data/raw/wos-core_SCIE_2026-October-20.csv \
      --out data/journal_index.json

Column names change between releases, so headers are matched fuzzily and the
header row is auto-detected (the discontinued sheet has title rows on top).
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import re
import sys
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.issn import normalize_issn  # noqa: E402

WOS_INDEX_NAMES = ("SCIE", "SSCI", "AHCI", "ESCI")
WOS_INDEX_FULLNAMES = {
    "science citation index expanded": "SCIE",
    "social sciences citation index": "SSCI",
    "arts & humanities citation index": "AHCI",
    "arts and humanities citation index": "AHCI",
    "emerging sources citation index": "ESCI",
}
JOURNAL_SOURCE_TYPES = {"journal", "trade journal"}


# --------------------------------------------------------------------------- reading


def _norm_header(h: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(h or "").lower()).strip()


def _rows_from_xlsx(path: Path) -> Iterator[tuple[str, list[list[Any]]]]:
    from openpyxl import load_workbook

    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            yield ws.title, [list(r) for r in ws.iter_rows(values_only=True)]
    finally:
        wb.close()


def _rows_from_csv(path: Path) -> Iterator[tuple[str, list[list[Any]]]]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    sample = text[:5000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    yield path.stem, [row for row in csv.reader(io.StringIO(text), dialect)]


def read_tables(path: Path) -> Iterator[tuple[str, list[list[Any]]]]:
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        yield from _rows_from_xlsx(path)
    elif path.suffix.lower() in {".csv", ".tsv", ".txt"}:
        yield from _rows_from_csv(path)
    else:
        raise SystemExit(f"Unsupported file type: {path} (use .xlsx or .csv)")


def find_header(rows: list[list[Any]], max_scan: int = 25) -> int | None:
    """Index of the first row that looks like a header (mentions ISSN and a title column)."""
    for i, row in enumerate(rows[:max_scan]):
        cells = [_norm_header(c) for c in row]
        if any("issn" in c for c in cells) and any("title" in c for c in cells):
            return i
    return None


def pick(headers: list[str], *candidates: str, contains: tuple[str, ...] = ()) -> int | None:
    """Find a column: exact match against candidates first, then substring match."""
    for cand in candidates:
        if cand in headers:
            return headers.index(cand)
    for i, h in enumerate(headers):
        if contains and all(c in h for c in contains):
            return i
    return None


def cell(row: list[Any], idx: int | None) -> Any:
    if idx is None or idx >= len(row):
        return None
    value = row[idx]
    if isinstance(value, str):
        value = value.strip()
        return value or None
    return value


def split_list(value: Any) -> list[str]:
    if not value:
        return []
    return [p.strip() for p in re.split(r"[;|]", str(value)) if p.strip()]


# --------------------------------------------------------------------------- index model


class IndexBuilder:
    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []
        self.by_issn: dict[str, int] = {}

    def _find_or_create(self, issns: list[str], title: str | None) -> dict[str, Any]:
        hits = sorted({self.by_issn[i] for i in issns if i in self.by_issn})
        if hits:
            rec = self.records[hits[0]]
            # Merge any further records that share an ISSN with this one.
            for other_idx in hits[1:]:
                other = self.records[other_idx]
                if other.get("_merged"):
                    continue
                for k in ("scopus", "wos"):
                    if other.get(k) and not rec.get(k):
                        rec[k] = other[k]
                rec["issns"] = list(dict.fromkeys(rec["issns"] + other["issns"]))
                other["_merged"] = True
                for i in other["issns"]:
                    self.by_issn[i] = hits[0]
        else:
            rec = {"title": title, "issns": []}
            self.records.append(rec)
            hits = [len(self.records) - 1]
        for i in issns:
            if i not in rec["issns"]:
                rec["issns"].append(i)
            self.by_issn[i] = hits[0]
        if title and not rec.get("title"):
            rec["title"] = title
        return rec

    def finish(self) -> list[dict[str, Any]]:
        return [r for r in self.records if not r.get("_merged")]


# --------------------------------------------------------------------------- Scopus


def load_scopus(path: Path, builder: IndexBuilder) -> dict[str, int]:
    counts = {"scopus": 0, "scopus_inactive": 0, "scopus_discontinued": 0, "skipped_non_journal": 0}
    for sheet, rows in read_tables(path):
        h = find_header(rows)
        if h is None:
            print(f"  [scopus] sheet '{sheet}': no header row found, skipped")
            continue
        headers = [_norm_header(c) for c in rows[h]]
        is_discontinued_sheet = "discontinu" in sheet.lower()

        c_id = pick(headers, "sourcerecord id", "source record id", "scopus source id", contains=("sourcerecord",))
        c_title = pick(headers, "source title", "title", contains=("title",))
        c_issn = pick(headers, "print issn", "issn", "p issn", contains=("print", "issn"))
        c_eissn = pick(headers, "e issn", "eissn", "electronic issn", contains=("e", "issn"))
        if c_eissn == c_issn:
            c_eissn = next((i for i, x in enumerate(headers) if "issn" in x and i != c_issn), None)
        c_status = pick(headers, "active or inactive", contains=("active",))
        c_type = pick(headers, "source type", contains=("source", "type"))
        c_pub = pick(headers, "publisher", "publisher s name", "publisher name", contains=("publisher",))
        c_asjc = pick(headers, contains=("asjc",))
        c_cov = pick(headers, "coverage", contains=("coverage",))
        c_reason = pick(headers, contains=("reason",))
        c_disc_flag = None
        if not is_discontinued_sheet:
            c_disc_flag = next(
                (i for i, x in enumerate(headers) if "discontinued" in x and "quality" in x), None
            )

        kind = "discontinued list" if is_discontinued_sheet else "source list"
        n = 0
        for row in rows[h + 1 :]:
            issns = [x for x in (normalize_issn(cell(row, c_issn)), normalize_issn(cell(row, c_eissn))) if x]
            if not issns:
                continue
            title = cell(row, c_title)
            stype = str(cell(row, c_type) or "journal").lower()
            if not is_discontinued_sheet and stype not in JOURNAL_SOURCE_TYPES:
                counts["skipped_non_journal"] += 1
                continue
            rec = builder._find_or_create(issns, str(title) if title else None)
            sc = rec.setdefault("scopus", {"status": "active"})
            if cell(row, c_id) is not None and "id" not in sc:
                sc["id"] = str(cell(row, c_id)).removesuffix(".0")
            if is_discontinued_sheet:
                sc["discontinued"] = True
                sc.setdefault("status", "inactive")
                if cell(row, c_reason):
                    sc["discontinued_reason"] = str(cell(row, c_reason))
                counts["scopus_discontinued"] += 1
            else:
                status = str(cell(row, c_status) or "Active").strip().lower()
                sc["status"] = "inactive" if status.startswith("inactive") else "active"
                if sc["status"] == "inactive":
                    counts["scopus_inactive"] += 1
                if c_disc_flag is not None and cell(row, c_disc_flag):
                    sc["discontinued"] = True
                    sc.setdefault("discontinued_reason", str(cell(row, c_disc_flag)))
                if cell(row, c_pub):
                    sc["publisher"] = str(cell(row, c_pub))
                if cell(row, c_asjc):
                    sc["asjc"] = split_list(cell(row, c_asjc))
                if cell(row, c_cov):
                    sc["coverage"] = str(cell(row, c_cov))
                counts["scopus"] += 1
            n += 1
        print(f"  [scopus] sheet '{sheet}' ({kind}): {n} rows")
    return counts


# --------------------------------------------------------------------------- Web of Science


def _guess_index(label: str) -> str | None:
    up = label.upper()
    for name in WOS_INDEX_NAMES:
        if re.search(rf"(^|[^A-Z]){name}([^A-Z]|$)", up):
            return name
    return None


def load_wos(path: Path, index_name: str | None, builder: IndexBuilder) -> dict[str, int]:
    counts: dict[str, int] = {}
    for sheet, rows in read_tables(path):
        h = find_header(rows)
        if h is None:
            print(f"  [wos] {path.name}/{sheet}: no header row found, skipped")
            continue
        headers = [_norm_header(c) for c in rows[h]]
        c_title = pick(headers, "journal title", "title", contains=("title",))
        c_issn = pick(headers, "issn", "print issn")
        c_eissn = pick(headers, "eissn", "e issn")
        c_pub = pick(headers, "publisher name", "publisher", contains=("publisher", "name"))
        c_cats = pick(headers, "web of science categories", contains=("categor",))
        c_coll = pick(headers, "web of science core collection", contains=("core", "collection"))

        n = 0
        for row in rows[h + 1 :]:
            issns = [x for x in (normalize_issn(cell(row, c_issn)), normalize_issn(cell(row, c_eissn))) if x]
            if not issns:
                continue
            idx_names: list[str] = []
            coll = cell(row, c_coll)
            if coll:
                for part in split_list(coll) or [str(coll)]:
                    name = WOS_INDEX_FULLNAMES.get(part.lower().strip()) or _guess_index(part)
                    if name:
                        idx_names.append(name)
            if not idx_names and index_name:
                idx_names = [index_name]
            if not idx_names:
                continue
            title = cell(row, c_title)
            rec = builder._find_or_create(issns, str(title) if title else None)
            wos = rec.setdefault("wos", {"indexes": []})
            for name in idx_names:
                if name not in wos["indexes"]:
                    wos["indexes"].append(name)
                    counts[name] = counts.get(name, 0) + 1
            if cell(row, c_pub):
                wos["publisher"] = str(cell(row, c_pub))
            cats = split_list(cell(row, c_cats))
            if cats:
                wos["categories"] = list(dict.fromkeys(wos.get("categories", []) + cats))
            n += 1
        print(f"  [wos] {path.name}/{sheet} ({'/'.join(sorted(set(counts))) or index_name}): {n} rows")
    return counts


# --------------------------------------------------------------------------- main


def build(scopus: Path | None, wos_inputs: list[tuple[str | None, Path]]) -> dict[str, Any]:
    builder = IndexBuilder()
    counts: dict[str, int] = {}
    inputs: list[dict[str, str]] = []
    if scopus:
        print(f"Reading Scopus list: {scopus}")
        counts.update(load_scopus(scopus, builder))
        inputs.append({"type": "scopus", "file": scopus.name})
    wos_total = 0
    for index_name, path in wos_inputs:
        name = index_name or _guess_index(path.stem)
        print(f"Reading Web of Science list: {path} ({name or 'from file column'})")
        c = load_wos(path, name, builder)
        for k, v in c.items():
            counts[k] = counts.get(k, 0) + v
            wos_total += v
        inputs.append({"type": "wos", "index": name or "auto", "file": path.name})
    counts["wos"] = wos_total
    records = builder.finish()
    for r in records:
        r.pop("_merged", None)
    counts["journals_total"] = len(records)
    return {
        "meta": {
            "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "inputs": inputs,
            "counts": counts,
            "schema": 1,
        },
        "records": records,
    }


def parse_wos_arg(value: str) -> tuple[str | None, Path]:
    if "=" in value and value.split("=", 1)[0].upper() in WOS_INDEX_NAMES:
        name, path = value.split("=", 1)
        return name.upper(), Path(path)
    return None, Path(value)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scopus", type=Path, help="Scopus Source Title List (.xlsx/.csv)")
    ap.add_argument("--wos", action="append", default=[], help="INDEX=PATH of a Master Journal List download")
    ap.add_argument("--out", type=Path, default=Path("data/journal_index.json"))
    args = ap.parse_args(argv)

    if not args.scopus and not args.wos:
        ap.error("Give at least --scopus or --wos.")
    wos_inputs = [parse_wos_arg(v) for v in args.wos]
    for p in [args.scopus, *(p for _, p in wos_inputs)]:
        if p and not p.is_file():
            ap.error(f"File not found: {p}")

    index = build(args.scopus, wos_inputs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(index, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    c = index["meta"]["counts"]
    print(
        f"\nWrote {args.out} — {c['journals_total']} journals "
        f"(Scopus rows: {c.get('scopus', 0)}, discontinued: {c.get('scopus_discontinued', 0)}, "
        f"SCIE: {c.get('SCIE', 0)}, ESCI: {c.get('ESCI', 0)})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Journal lists (Scopus + Web of Science)

JournalMatch never guesses whether a journal is indexed. It reads the **official** lists that you
download yourself, and `scripts/build_index.py` turns them into `data/journal_index.json`.

Both lists are updated about **monthly**. Rebuild the index every month.

## 1. Scopus Source Title List (Elsevier)

1. Go to <https://www.scopus.com/sources> (free, no subscription needed) or Elsevier's
   "Content coverage" page.
2. Click **Download Scopus Source List**. You get an `.xlsx` file such as `ext_list_October_2026.xlsx`.
3. Save it in `data/raw/`.

The workbook includes a **Discontinued titles** sheet. The builder reads it automatically and
flags those journals as *Scopus discontinued*. Scopus has stopped indexing them, usually because
of publication concerns.

## 2. Web of Science Master Journal List (Clarivate), SCIE

1. Create a free account at <https://mjl.clarivate.com/>.
2. Open **Downloads** (collection list downloads) and download the
   **Science Citation Index Expanded** CSV. Optionally also download **ESCI** so the app can say
   "ESCI, not SCIE" instead of "not found".
3. Save the files in `data/raw/`.

## 3. Build the index

```bash
python scripts/build_index.py \
  --scopus data/raw/ext_list_October_2026.xlsx \
  --wos SCIE=data/raw/wos-core_SCIE.csv \
  --wos ESCI=data/raw/wos-core_ESCI.csv
```

Then restart the server. `GET /api/status` shows how many journals were loaded and when.

## Licensing: please read

These lists belong to Elsevier and Clarivate. Their terms limit redistribution, so **`data/raw/`
and `data/journal_index.json` are in `.gitignore`**. Do not commit them to a public repository.
Keep them on your server. On Docker, the `data/` folder is mounted as a volume.

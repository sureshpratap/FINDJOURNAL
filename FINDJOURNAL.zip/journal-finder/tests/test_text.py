from app.issn import format_issn, is_valid_checksum, normalize_issn
from app.text import TfidfSimilarity, extract_keywords, keyword_query, rebuild_abstract, terms


def test_terms_drop_stopwords_and_build_bigrams():
    t = terms("The wear of thermal spray coatings")
    assert "the" not in t
    assert "thermal spray" in t
    assert "spray coating" in t  # plural stemmed


def test_extract_keywords_prefers_title_phrases():
    kws = extract_keywords(
        "HVOF thermal spray coatings for engine pistons",
        "Thermal spray coatings were deposited by HVOF. The thermal spray process improved wear.",
    )
    assert kws[0] == "thermal spray"
    assert "hvof" in kws
    assert len(kws) <= 8


def test_keyword_query_quotes_phrases():
    assert keyword_query(["thermal spray", "hvof"]) == '"thermal spray" OR hvof'


def test_rebuild_abstract():
    assert rebuild_abstract({"world": [1], "hello": [0], "again": [2]}) == "hello world again"
    assert rebuild_abstract(None) == ""


def test_tfidf_ranks_relevant_document_first():
    docs = [
        "Deep learning for image classification of tumours",
        "HVOF sprayed WC-Co coatings: sliding wear and erosion resistance",
        "Monetary policy and inflation expectations",
    ]
    sims = TfidfSimilarity(docs).query("wear resistance of HVOF WC-Co coatings")
    assert max(range(3), key=sims.__getitem__) == 1
    assert sims[2] == 0.0


def test_issn_normalisation():
    assert normalize_issn("0257-8972") == "02578972"
    assert normalize_issn(2578972) == "02578972"  # Excel dropped the leading zero
    assert normalize_issn("2578972.0") == "02578972"
    assert normalize_issn("1234-567x") == "1234567X"
    assert normalize_issn("") is None
    assert normalize_issn("not an issn at all") is None
    assert format_issn("1234567X") == "1234-567X"


def test_issn_checksum():
    assert is_valid_checksum("02578972")  # Surface and Coatings Technology
    assert is_valid_checksum("00280836")  # Nature
    assert not is_valid_checksum("02578971")

"""End-to-end API tests with OpenAlex mocked by respx (no network, no API key needed)."""

from dataclasses import replace

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from app.config import settings
from app.index_store import JournalIndex
from app.main import create_app
from app.openalex import OpenAlexClient

BASE = "https://api.openalex.test"


def inv(text):
    out = {}
    for i, w in enumerate(text.split()):
        out.setdefault(w, []).append(i)
    return out


def work(wid, title, abstract, source_id, source_name, issn, score=1.0):
    return {
        "id": f"https://openalex.org/W{wid}",
        "doi": f"https://doi.org/10.1/{wid}",
        "title": title,
        "publication_year": 2025,
        "relevance_score": score,
        "abstract_inverted_index": inv(abstract),
        "cited_by_count": 3,
        "type": "article",
        "primary_location": {
            "source": {
                "id": f"https://openalex.org/{source_id}",
                "display_name": source_name,
                "issn_l": issn,
                "issn": [issn],
                "type": "journal",
            }
        },
        "authorships": [
            {"author": {"id": f"https://openalex.org/A{wid}", "display_name": f"Author {wid}"}, "institutions": []}
        ],
    }


COATING = "HVOF thermal spray coatings wear resistance of NiCrAlY bond coat on pistons"
KEYWORD_WORKS = [
    work(1, "HVOF thermal spray coatings for pistons", COATING, "S1", "Coatings Journal", "1111-1111"),
    work(2, "Wear of thermal spray NiCrAlY coatings", COATING, "S1", "Coatings Journal", "1111-1111"),
    work(3, "Thermal spray coating wear on engines", COATING, "S2", "Predatory Engineering Review", "2222-2222"),
    work(4, "Thermal barrier coatings review", "thermal barrier coating ceramics", "S3", "Ceramics Letters", "3333-3333"),
]
SEMANTIC_WORKS = [
    work(5, "Graded coatings for IC engine pistons", COATING, "S3", "Ceramics Letters", "3333-3333", score=0.9),
    work(1, "HVOF thermal spray coatings for pistons", COATING, "S1", "Coatings Journal", "1111-1111", score=0.8),
]
SOURCES = [
    {"id": "https://openalex.org/S1", "display_name": "Coatings Journal", "issn_l": "1111-1111",
     "issn": ["1111-1111"], "summary_stats": {"h_index": 150, "2yr_mean_citedness": 5.2},
     "homepage_url": "https://example.org/cj", "apc_usd": 2500, "is_oa": False, "is_in_doaj": False},
]


def make_index():
    return JournalIndex(
        [
            {"title": "COATINGS JOURNAL", "issns": ["11111111"],
             "scopus": {"status": "active", "id": "999"}, "wos": {"indexes": ["SCIE"], "categories": ["Materials Science"]}},
            {"title": "CERAMICS LETTERS", "issns": ["33333333"], "scopus": {"status": "active", "id": "888"}},
        ],
        {"counts": {"scopus": 2, "wos": 1, "SCIE": 1}, "built_at": "2026-11-01T00:00:00+00:00"},
    )


@pytest.fixture
def mocked():
    with respx.mock(base_url=BASE, assert_all_called=False) as router:
        def works(request):
            params = request.url.params
            assert params.get("api_key") == "test-key"
            assert "primary_location.source.type:journal" in params["filter"]
            if "search.semantic" in params:
                return httpx.Response(200, json={"results": SEMANTIC_WORKS})
            return httpx.Response(200, json={"results": KEYWORD_WORKS})

        router.get("/works").mock(side_effect=works)
        router.get("/sources").mock(return_value=httpx.Response(200, json={"results": SOURCES}))
        yield router


def client_for(index):
    cfg = replace(settings, openalex_api_key="test-key", openalex_base_url=BASE, rate_limit_per_minute=100)
    oa = OpenAlexClient(cfg, httpx.AsyncClient(base_url=BASE))
    return TestClient(create_app(cfg, client=oa, index=index))


PAYLOAD = {"title": "HVOF thermal spray coatings for engine pistons", "abstract": COATING}


def test_suggest_ranks_and_filters(mocked):
    with client_for(make_index()) as c:
        r = c.post("/api/suggest", json=PAYLOAD)
        assert r.status_code == 200, r.text
        d = r.json()
        names = [j["name"] for j in d["journals"]]
        # Default filter = Scopus or SCIE → the unindexed journal is hidden.
        assert names == ["Coatings Journal", "Ceramics Letters"]
        assert d["hidden_by_filter"] == 1
        top = d["journals"][0]
        assert top["score"] == 100.0 and top["n_similar"] == 2
        assert top["indexing"]["scopus"] and top["indexing"]["scie"]
        assert top["h_index"] == 150 and top["apc_usd"] == 2500
        assert d["stats"]["semantic_used"] and d["stats"]["candidates"] == 5
        assert d["authors"] and d["articles"]

        # Second identical request is served from cache.
        assert c.post("/api/suggest", json=PAYLOAD).json()["cached"] is True


def test_show_all_includes_unindexed(mocked):
    with client_for(make_index()) as c:
        d = c.post("/api/suggest", json={**PAYLOAD, "indexing": "all", "semantic": False}).json()
        names = [j["name"] for j in d["journals"]]
        assert "Predatory Engineering Review" in names
        pred = next(j for j in d["journals"] if j["name"] == "Predatory Engineering Review")
        assert pred["indexing"]["matched"] is False
        assert not d["stats"]["semantic_used"]


def test_scie_filter(mocked):
    with client_for(make_index()) as c:
        d = c.post("/api/suggest", json={**PAYLOAD, "indexing": "scie"}).json()
        assert [j["name"] for j in d["journals"]] == ["Coatings Journal"]


def test_without_index_everything_shown_with_warning(mocked):
    with client_for(JournalIndex()) as c:
        d = c.post("/api/suggest", json=PAYLOAD).json()
        assert len(d["journals"]) == 3
        assert any("index has not been built" in w for w in d["warnings"])


def test_validation_and_verify(mocked):
    with client_for(make_index()) as c:
        assert c.post("/api/suggest", json={"title": "short"}).status_code == 422
        v = c.get("/api/journal/1111-1111").json()
        assert v["verified"] and v["scopus"] and v["scie"] and v["issn"] == "1111-1111"
        assert c.get("/api/journal/abc").status_code == 422
        s = c.get("/api/status").json()
        assert s["index"]["journals"] == 2 and s["openalex_key_configured"]
        assert c.get("/").status_code == 200


def test_openalex_quota_error_is_reported():
    with respx.mock(base_url=BASE) as router:
        router.get("/works").mock(return_value=httpx.Response(429, text="limit"))
        with client_for(make_index()) as c:
            r = c.post("/api/suggest", json=PAYLOAD)
            assert r.status_code == 502
            assert "credit limit" in r.json()["detail"]

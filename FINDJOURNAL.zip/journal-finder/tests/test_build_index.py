"""The index builder against small synthetic files shaped like the official downloads."""

import json

from openpyxl import Workbook

from app.index_store import JournalIndex, passes_filter
from scripts.build_index import main


def make_scopus_xlsx(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Scopus Sources October 2026"
    ws.append(
        [
            "Sourcerecord ID",
            "Source Title",
            "ISSN",
            "EISSN",
            "Active or Inactive",
            "Coverage",
            "Titles discontinued by Scopus due to quality issues",
            "Source Type",
            "Publisher",
            "All Science Journal Classification Codes (ASJC)",
        ]
    )
    ws.append([111, "Journal Alpha", 2578972, "18793347", "Active", "1986-2026", None, "Journal", "Pub A", "2508; 3110;"])
    ws.append([222, "Journal Beta", "1000000X", None, "Inactive", "2001-2010", None, "Journal", "Pub B", "2200;"])
    ws.append([333, "Book Series Gamma", "20000001", None, "Active", "", None, "Book Series", "Pub C", ""])
    ws.append([444, "Journal Delta", "30000002", "30000003", "Active", "2015-2026", None, "Journal", "Pub D", "1000;"])

    disc = wb.create_sheet("Discontinued titles Oct. 2026")
    disc.append(["Status (recently discontinued titles in bold): October 2026"])
    disc.append([])
    disc.append(["Sourcerecord ID", "Source Title (newly added titles are highlighted in red)", "Print-ISSN", "E-ISSN", "Publisher", "Reason for discontinuation"])
    disc.append([444, "Journal Delta", "30000002", "30000003", "Pub D", "Publication Concerns"])
    wb.save(path)


def make_mjl_csv(path, rows):
    header = '"Journal title","ISSN","eISSN","Publisher name","Publisher address","Languages","Web of Science Categories"\n'
    body = "".join(",".join(f'"{c}"' for c in r) + "\n" for r in rows)
    path.write_text(header + body, encoding="utf-8")


def test_build_and_lookup(tmp_path):
    scopus = tmp_path / "ext_list_October_2026.xlsx"
    make_scopus_xlsx(scopus)
    scie = tmp_path / "wos-core_SCIE_2026.csv"
    make_mjl_csv(
        scie,
        [
            ["JOURNAL ALPHA", "", "1879-3347", "Pub A", "City", "English", "Materials Science, Coatings & Films | Physics, Applied"],
            ["JOURNAL EPSILON", "4000-0004", "", "Pub E", "City", "English", "Engineering, Mechanical"],
        ],
    )
    esci = tmp_path / "wos-core_ESCI_2026.csv"
    make_mjl_csv(esci, [["JOURNAL ZETA", "5000-0005", "", "Pub Z", "City", "English", "Engineering, Multidisciplinary"]])
    out = tmp_path / "index.json"

    assert main(["--scopus", str(scopus), "--wos", f"SCIE={scie}", "--wos", str(esci), "--out", str(out)]) == 0
    payload = json.loads(out.read_text())
    counts = payload["meta"]["counts"]
    assert counts["scopus"] == 3  # book series skipped
    assert counts["skipped_non_journal"] == 1
    assert counts["scopus_discontinued"] == 1
    assert counts["SCIE"] == 2 and counts["ESCI"] == 1

    idx = JournalIndex.load(out)

    alpha = idx.status(["0257-8972"])  # print ISSN from Scopus (leading zero restored)
    assert alpha["scopus"] and alpha["scie"]  # merged with MJL row via eISSN
    assert alpha["scopus_id"] == "111"
    assert alpha["wos_categories"][0] == "Materials Science, Coatings & Films"
    assert passes_filter(alpha, "both")

    beta = idx.status(["1000-000X"])
    assert beta["matched"] and beta["scopus_inactive"] and not beta["scopus"]
    assert not passes_filter(beta, "any")

    delta = idx.status(["30000003"])
    assert delta["scopus_discontinued"] and not delta["scopus"]
    assert delta["scopus_reason"] == "Publication Concerns"

    epsilon = idx.status(["4000-0004"])
    assert epsilon["scie"] and not epsilon["scopus"]
    assert passes_filter(epsilon, "scie") and not passes_filter(epsilon, "scopus")

    zeta = idx.status(["5000-0005"])
    assert zeta["wos_indexes"] == ["ESCI"] and not zeta["scie"] and not zeta["verified"]

    unknown = idx.status(["9999-9999"])
    assert not unknown["matched"]
    assert passes_filter(unknown, "all") and not passes_filter(unknown, "any")

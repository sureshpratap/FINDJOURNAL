"""Text processing: keyword extraction, abstract reconstruction and TF-IDF similarity.

Pure Python on purpose — no numpy / scikit-learn — so the app stays light and
easy to deploy on free hosting tiers. The candidate set per query is only a few
hundred documents, which is trivial for this approach.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Iterable, Sequence

# General English stop words plus words that are common in *every* abstract and
# therefore carry no topical signal.
STOPWORDS: frozenset[str] = frozenset(
    """
    a about above according across after again against all almost along already also although
    always am among an and another any are around as at be became because been before being
    below between both but by can cannot could did do does doing done down due during each
    either else enough especially etc even ever every few for from further furthermore had has
    have having he hence her here hers herself him himself his how however i if in into is it
    its itself just last least less let like made mainly make makes many may me might more
    moreover most mostly much must my namely near nearly neither never nevertheless next no nor
    not now of off often on once one only onto or other others otherwise our ours ourselves out
    over overall own per perhaps quite rather really regarding same several shall she should
    show showed shown shows since so some still such than that the their theirs them themselves
    then there thereby therefore these they this those though three through throughout thus to
    together too toward towards two under until up upon us use used uses using various very via
    was we well were what whatever when where whereas whether which while who whom whose why
    will with within without would yet you your yours

    abstract aim aimed aims analysis analyses analyzed analysed approach approaches article
    based best better case conclusion conclusions conducted considered current data demonstrate
    demonstrated demonstrates describe described different discuss discussed effect effects
    evaluate evaluated evaluation examine examined experimental experiment experiments finding
    findings first found furthermore given good high higher however important improve improved
    including increase increased indicate indicated investigate investigated investigation key
    large low lower main method methods methodology new novel number obtain obtained paper
    particular performed present presented propose proposed provide provided purpose recent
    related report reported research respectively result results reveal revealed review role
    second significant significantly similar studied studies study suggest suggested technique
    techniques total type types work works year years within
    """.split()
)

_TOKEN_RE = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*")
_SPLIT_RE = re.compile(r"[.,;:!?()\[\]{}\"“”'’/\\|<>=+*%]+")


def _stem(token: str) -> str:
    """Very light plural stemming; keeps terms human-readable for display."""
    if len(token) > 4 and token.endswith("ies"):
        return token[:-3] + "y"
    if len(token) > 4 and token.endswith("sses"):
        return token[:-2]
    if len(token) > 3 and token.endswith("s") and not token.endswith(("ss", "us", "is")):
        return token[:-1]
    return token


def _is_content(token: str) -> bool:
    return len(token) >= 3 and token not in STOPWORDS and not token.isdigit()


def _chunks(text: str) -> list[list[str]]:
    """Split text into runs of content words (stop words and punctuation break runs)."""
    chunks: list[list[str]] = []
    for segment in _SPLIT_RE.split(text.lower()):
        current: list[str] = []
        for tok in _TOKEN_RE.findall(segment):
            if _is_content(tok):
                current.append(_stem(tok))
            elif current:
                chunks.append(current)
                current = []
        if current:
            chunks.append(current)
    return chunks


def terms(text: str, bigrams: bool = True) -> list[str]:
    """Return unigram (+ optional bigram) terms for a piece of text."""
    out: list[str] = []
    for chunk in _chunks(text or ""):
        out.extend(chunk)
        if bigrams:
            out.extend(f"{a} {b}" for a, b in zip(chunk, chunk[1:]))
    return out


def extract_keywords(title: str, abstract: str, n: int = 8) -> list[str]:
    """Pick the most informative terms from a manuscript title + abstract.

    Title terms are weighted 3x, bigrams 1.6x. Unigrams already covered by a
    selected bigram are skipped so the list stays diverse.
    """
    scores: Counter[str] = Counter()
    occurrences: Counter[str] = Counter()
    for term in terms(title):
        scores[term] += 3.0
        occurrences[term] += 1
    for term in terms(abstract):
        scores[term] += 1.0
        occurrences[term] += 1
    for term in list(scores):
        if " " in term:
            # A word pair seen once is usually an accident of phrasing; seen twice it is a phrase.
            scores[term] *= 1.6 if occurrences[term] >= 2 else 0.5

    chosen: list[str] = []
    covered: set[str] = set()
    for term, _ in sorted(scores.items(), key=lambda kv: (-kv[1], kv[0])):
        parts = term.split()
        if len(parts) == 1 and term in covered:
            continue
        if len(parts) == 2 and all(p in covered for p in parts):
            continue
        chosen.append(term)
        covered.update(parts)
        if len(chosen) >= n:
            break
    return chosen


def keyword_query(keywords: Sequence[str]) -> str:
    """Build an OpenAlex boolean query: phrases quoted, terms OR-ed.

    OpenAlex ranks results by relevance, so documents matching more of the
    terms rise to the top even though the query itself is an OR.
    """
    parts = [f'"{k}"' if " " in k else k for k in keywords]
    return " OR ".join(parts)


def rebuild_abstract(inverted_index: dict[str, list[int]] | None) -> str:
    """OpenAlex ships abstracts as {word: [positions]}; turn that back into text."""
    if not inverted_index:
        return ""
    positions: list[tuple[int, str]] = []
    for word, idxs in inverted_index.items():
        positions.extend((i, word) for i in idxs)
    positions.sort()
    return " ".join(word for _, word in positions)


class TfidfSimilarity:
    """Cosine similarity between a query and a small document collection."""

    def __init__(self, documents: Iterable[str]):
        self._doc_terms = [Counter(terms(d)) for d in documents]
        df: Counter[str] = Counter()
        for tf in self._doc_terms:
            df.update(tf.keys())
        n_docs = max(len(self._doc_terms), 1)
        # Smoothed IDF (as in scikit-learn) so terms in every document still count a little.
        self._idf = {t: math.log((1 + n_docs) / (1 + c)) + 1.0 for t, c in df.items()}
        self._doc_vecs = [self._vector(tf) for tf in self._doc_terms]

    def _vector(self, tf: Counter[str]) -> dict[str, float]:
        vec = {
            t: (1.0 + math.log(c)) * self._idf.get(t, 0.0)
            for t, c in tf.items()
            if t in self._idf
        }
        norm = math.sqrt(sum(v * v for v in vec.values()))
        return {t: v / norm for t, v in vec.items()} if norm else {}

    def query(self, text: str) -> list[float]:
        q = self._vector(Counter(terms(text)))
        if not q:
            return [0.0] * len(self._doc_vecs)
        return [sum(w * d.get(t, 0.0) for t, w in q.items()) for d in self._doc_vecs]

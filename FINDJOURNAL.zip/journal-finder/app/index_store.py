"""Loads the locally built Scopus / Web of Science journal index and answers ISSN lookups.

The index file is produced by ``scripts/build_index.py`` from the *official*
lists (Elsevier's Scopus Source Title List and Clarivate's Master Journal List
downloads). Indexing status is therefore never guessed from third-party data.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from .issn import format_issn, normalize_issn

log = logging.getLogger(__name__)


class JournalIndex:
    def __init__(self, records: list[dict[str, Any]] | None = None, meta: dict | None = None):
        self.records: list[dict[str, Any]] = records or []
        self.meta: dict[str, Any] = meta or {}
        self._by_issn: dict[str, int] = {}
        for i, rec in enumerate(self.records):
            for issn in rec.get("issns", []):
                self._by_issn.setdefault(issn, i)

    @classmethod
    def load(cls, path: Path) -> JournalIndex:
        if not path.is_file():
            log.warning("Journal index not found at %s — indexing status will be 'unknown'.", path)
            return cls()
        with path.open(encoding="utf-8") as fh:
            payload = json.load(fh)
        index = cls(payload.get("records", []), payload.get("meta", {}))
        log.info("Loaded journal index: %d journals from %s", len(index.records), path)
        return index

    @property
    def loaded(self) -> bool:
        return bool(self.records)

    @property
    def has_scopus(self) -> bool:
        return bool(self.meta.get("counts", {}).get("scopus"))

    @property
    def has_wos(self) -> bool:
        return bool(self.meta.get("counts", {}).get("wos"))

    def lookup(self, issns: Iterable[str | None]) -> dict[str, Any] | None:
        for raw in issns:
            issn = normalize_issn(raw)
            if issn and issn in self._by_issn:
                return self.records[self._by_issn[issn]]
        return None

    def status(self, issns: Iterable[str | None]) -> dict[str, Any]:
        """Summarise indexing status for a journal identified by any of its ISSNs."""
        rec = self.lookup(list(issns))
        scopus = (rec or {}).get("scopus")
        wos = (rec or {}).get("wos")
        wos_indexes = (wos or {}).get("indexes", [])

        scopus_active = bool(
            scopus and scopus.get("status", "active") == "active" and not scopus.get("discontinued")
        )
        result: dict[str, Any] = {
            "matched": rec is not None,
            "index_title": (rec or {}).get("title"),
            "scopus": scopus_active,
            "scopus_discontinued": bool(scopus and scopus.get("discontinued")),
            "scopus_inactive": bool(scopus and scopus.get("status") == "inactive"),
            "scopus_reason": (scopus or {}).get("discontinued_reason"),
            "scopus_id": (scopus or {}).get("id"),
            "scopus_subjects": (scopus or {}).get("asjc", [])[:6],
            "scie": "SCIE" in wos_indexes,
            "wos_indexes": wos_indexes,
            "wos_categories": (wos or {}).get("categories", [])[:6],
            "index_issns": [format_issn(i) for i in (rec or {}).get("issns", [])],
        }
        result["verified"] = result["scopus"] or result["scie"]
        return result


def passes_filter(status: dict[str, Any], indexing: str) -> bool:
    """indexing: 'any' (Scopus or SCIE), 'scopus', 'scie', 'both', or 'all' (no filter)."""
    if indexing == "all":
        return True
    if indexing == "scopus":
        return status["scopus"]
    if indexing == "scie":
        return status["scie"]
    if indexing == "both":
        return status["scopus"] and status["scie"]
    return status["scopus"] or status["scie"]

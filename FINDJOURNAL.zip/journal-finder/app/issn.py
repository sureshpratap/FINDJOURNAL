"""ISSN helpers shared by the API and the index builder."""

from __future__ import annotations

import re

_NON_ALNUM = re.compile(r"[^0-9Xx]")


def normalize_issn(value: object) -> str | None:
    """Return an 8-character ISSN without hyphen (e.g. '0240642X'), or None.

    Handles the quirks of spreadsheet exports: numeric cells that lost leading
    zeros (240642 -> '00240642'), floats ('12345678.0'), hyphens and spaces.
    """
    if value is None:
        return None
    if isinstance(value, float):
        if value != value:  # NaN
            return None
        value = int(value)
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    text = _NON_ALNUM.sub("", text).upper()
    if not text or len(text) > 8:
        return None
    text = text.zfill(8)
    if "X" in text[:-1]:
        return None
    return text


def format_issn(issn: str) -> str:
    """'0240642X' -> '0240-642X'."""
    return f"{issn[:4]}-{issn[4:]}" if len(issn) == 8 else issn


def is_valid_checksum(issn: str) -> bool:
    """Validate the ISSN check digit (mod 11)."""
    if len(issn) != 8 or not issn[:7].isdigit():
        return False
    total = sum(int(d) * w for d, w in zip(issn[:7], range(8, 1, -1)))
    check = (11 - total % 11) % 11
    expected = "X" if check == 10 else str(check)
    return issn[7] == expected

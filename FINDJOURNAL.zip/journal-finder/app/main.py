"""FastAPI application: JSON API + static single-page frontend."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

from . import __version__
from .cache import RateLimiter, TTLCache
from .config import Settings, settings
from .index_store import JournalIndex, passes_filter
from .issn import format_issn, is_valid_checksum, normalize_issn
from .openalex import OpenAlexClient, OpenAlexError
from .ranking import aggregate_authors, aggregate_journals, merge_candidates, score_articles
from .text import extract_keywords, keyword_query

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("journalmatch")

STATIC_DIR = Path(__file__).parent / "static"
MAX_JOURNALS = 30


class SuggestRequest(BaseModel):
    title: str = Field("", max_length=600)
    abstract: str = Field("", max_length=12000)
    years: int = Field(5, ge=0, le=30, description="Only consider articles from the last N years (0 = all).")
    open_access: Literal["any", "only", "exclude"] = "any"
    indexing: Literal["any", "scopus", "scie", "both", "all"] = "any"
    semantic: bool = True

    @model_validator(mode="after")
    def _enough_text(self) -> SuggestRequest:
        if len((self.title + " " + self.abstract).strip()) < 20:
            raise ValueError("Please paste a title and/or abstract (at least 20 characters).")
        return self


def create_app(
    cfg: Settings = settings,
    client: OpenAlexClient | None = None,
    index: JournalIndex | None = None,
) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.client = client or OpenAlexClient(cfg)
        app.state.index = index if index is not None else JournalIndex.load(cfg.index_path)
        if not cfg.openalex_api_key:
            log.warning("OPENALEX_API_KEY is not set — OpenAlex allows only a tiny demo quota.")
        yield
        await app.state.client.aclose()

    app = FastAPI(title="JournalMatch", version=__version__, lifespan=lifespan)
    cache = TTLCache(cfg.cache_ttl_seconds, cfg.cache_max_items)
    limiter = RateLimiter(cfg.rate_limit_per_minute)

    @app.get("/api/status")
    async def status(request: Request) -> dict[str, Any]:
        idx: JournalIndex = request.app.state.index
        return {
            "version": __version__,
            "openalex_key_configured": bool(cfg.openalex_api_key),
            "semantic_available": cfg.enable_semantic,
            "index": {
                "loaded": idx.loaded,
                "journals": len(idx.records),
                "built_at": idx.meta.get("built_at"),
                "counts": idx.meta.get("counts", {}),
                "inputs": idx.meta.get("inputs", []),
            },
        }

    @app.get("/api/journal/{issn}")
    async def verify_journal(issn: str, request: Request) -> dict[str, Any]:
        norm = normalize_issn(issn)
        if not norm:
            raise HTTPException(422, "That does not look like an ISSN (format 1234-567X).")
        idx: JournalIndex = request.app.state.index
        result = idx.status([norm])
        result["issn"] = format_issn(norm)
        result["checksum_valid"] = is_valid_checksum(norm)
        result["index_loaded"] = idx.loaded
        return result

    @app.post("/api/suggest")
    async def suggest(body: SuggestRequest, request: Request) -> dict[str, Any]:
        client_ip = request.client.host if request.client else "unknown"
        key = hashlib.sha256(json.dumps(body.model_dump(), sort_keys=True).encode()).hexdigest()
        cached = cache.get(key)
        if cached is not None:
            return {**cached, "cached": True}
        if not limiter.allow(client_ip):
            raise HTTPException(429, "Too many searches. Please wait a minute and try again.")

        oa: OpenAlexClient = request.app.state.client
        idx: JournalIndex = request.app.state.index
        result = await run_search(body, oa, idx, cfg)
        cache.set(key, result)
        return {**result, "cached": False}

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/", include_in_schema=False)
    async def home() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    return app


async def run_search(
    body: SuggestRequest, oa: OpenAlexClient, idx: JournalIndex, cfg: Settings
) -> dict[str, Any]:
    warnings: list[str] = []
    keywords = extract_keywords(body.title, body.abstract)
    if not keywords:
        raise HTTPException(422, "Could not find meaningful keywords. Please add more text.")
    kw_query = keyword_query(keywords)
    flt = OpenAlexClient.build_filter(body.years, body.open_access)
    full_text = f"{body.title}. {body.abstract}".strip(". ")

    use_semantic = body.semantic and cfg.enable_semantic
    tasks = [oa.keyword_search(kw_query, flt)]
    if use_semantic:
        tasks.append(oa.semantic_search(full_text, flt))
    outcomes = await asyncio.gather(*tasks, return_exceptions=True)

    keyword_works: list[dict] = []
    semantic_works: list[dict] = []
    errors: list[str] = []
    for i, outcome in enumerate(outcomes):
        if isinstance(outcome, Exception):
            errors.append(str(outcome))
            log.warning("OpenAlex search failed: %s", outcome)
        elif i == 0:
            keyword_works = outcome
        else:
            semantic_works = outcome
    if not keyword_works and not semantic_works:
        msg = errors[0] if errors else "No similar articles found. Try a longer abstract."
        raise HTTPException(502 if errors else 404, msg)
    if errors:
        warnings.append("One of the two searches failed; results may be less complete.")

    ranked = score_articles(full_text, merge_candidates(keyword_works, semantic_works))
    candidates = aggregate_journals(ranked)

    # Enrich the top journals with metrics (h-index, APC, homepage) in a single call.
    details: dict[str, dict] = {}
    try:
        details = await oa.sources([c.source["id"] for c in candidates[:100]])
    except OpenAlexError as exc:
        warnings.append("Journal metrics could not be loaded right now.")
        log.warning("Source lookup failed: %s", exc)

    if not idx.loaded:
        warnings.append(
            "The Scopus/SCIE index has not been built on this server, so no journal can be "
            "verified. Ask the administrator to run scripts/build_index.py."
        )

    top_score = candidates[0].score if candidates else 1.0
    journals: list[dict[str, Any]] = []
    hidden = 0
    for cand in candidates:
        src = {**cand.source, **details.get(cand.source["id"], {})}
        issns = [src.get("issn_l"), *(src.get("issn") or [])]
        status = idx.status(issns)
        if idx.loaded and not passes_filter(status, body.indexing):
            hidden += 1
            continue
        stats = src.get("summary_stats") or {}
        journals.append(
            {
                "id": src["id"],
                "name": src.get("display_name"),
                "publisher": src.get("host_organization_name"),
                "issns": [format_issn(i) for i in dict.fromkeys(x for x in issns if x)],
                "homepage": src.get("homepage_url"),
                "is_oa": src.get("is_oa"),
                "in_doaj": src.get("is_in_doaj"),
                "apc_usd": src.get("apc_usd"),
                "h_index": stats.get("h_index"),
                "mean_citedness_2yr": stats.get("2yr_mean_citedness"),
                "country": src.get("country_code"),
                "score": round(100 * cand.score / top_score, 1),
                "n_similar": len(cand.articles),
                "articles": [a.public() for a in cand.articles[:8]],
                "indexing": status,
            }
        )
        if len(journals) >= MAX_JOURNALS:
            break

    return {
        "keywords": keywords,
        "query": kw_query,
        "journals": journals,
        "hidden_by_filter": hidden,
        "articles": [a.public() for a in ranked[:50]],
        "authors": aggregate_authors(ranked),
        "stats": {
            "candidates": len(ranked),
            "keyword_hits": len(keyword_works),
            "semantic_hits": len(semantic_works),
            "semantic_used": use_semantic,
            "index_loaded": idx.loaded,
        },
        "warnings": warnings,
    }


app = create_app()

"""Tiny in-memory TTL cache and per-IP rate limiter (no Redis needed for one instance)."""

from __future__ import annotations

import time
from collections import OrderedDict, defaultdict, deque
from typing import Any


class TTLCache:
    def __init__(self, ttl_seconds: int, max_items: int):
        self.ttl = ttl_seconds
        self.max_items = max_items
        self._data: OrderedDict[str, tuple[float, Any]] = OrderedDict()

    def get(self, key: str) -> Any | None:
        item = self._data.get(key)
        if item is None:
            return None
        expires, value = item
        if expires < time.monotonic():
            self._data.pop(key, None)
            return None
        self._data.move_to_end(key)
        return value

    def set(self, key: str, value: Any) -> None:
        if self.ttl <= 0 or self.max_items <= 0:
            return
        self._data[key] = (time.monotonic() + self.ttl, value)
        self._data.move_to_end(key)
        while len(self._data) > self.max_items:
            self._data.popitem(last=False)


class RateLimiter:
    """Sliding-window limiter: at most `limit` requests per 60 s per client key."""

    def __init__(self, limit_per_minute: int):
        self.limit = limit_per_minute
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        if self.limit <= 0:
            return True
        now = time.monotonic()
        hits = self._hits[key]
        while hits and hits[0] <= now - 60:
            hits.popleft()
        if len(hits) >= self.limit:
            return False
        hits.append(now)
        return True

"""Runtime configuration, read from environment variables (or a .env file)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    """Minimal .env loader so we don't need python-dotenv as a dependency."""
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(ROOT_DIR / ".env")


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    openalex_api_key: str = field(default_factory=lambda: os.getenv("OPENALEX_API_KEY", ""))
    openalex_base_url: str = field(
        default_factory=lambda: os.getenv("OPENALEX_BASE_URL", "https://api.openalex.org")
    )
    # Contact address sent to OpenAlex as `mailto` (good API citizenship). Optional.
    contact_email: str = field(default_factory=lambda: os.getenv("CONTACT_EMAIL", ""))
    # Semantic (embedding) search costs 10x a keyword search on OpenAlex.
    enable_semantic: bool = field(default_factory=lambda: _bool("ENABLE_SEMANTIC_SEARCH", True))
    index_path: Path = field(
        default_factory=lambda: Path(
            os.getenv("JOURNAL_INDEX_PATH", str(ROOT_DIR / "data" / "journal_index.json"))
        )
    )
    cache_ttl_seconds: int = field(default_factory=lambda: _int("CACHE_TTL_SECONDS", 6 * 3600))
    cache_max_items: int = field(default_factory=lambda: _int("CACHE_MAX_ITEMS", 500))
    rate_limit_per_minute: int = field(default_factory=lambda: _int("RATE_LIMIT_PER_MINUTE", 20))
    request_timeout: float = field(default_factory=lambda: float(_int("OPENALEX_TIMEOUT", 30)))


settings = Settings()

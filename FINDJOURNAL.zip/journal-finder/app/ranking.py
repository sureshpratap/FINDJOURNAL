"""Ranking: turn similar articles into journal, article and author suggestions.

Method (in the spirit of JANE, Schuemie & Kors 2008):
 1. Retrieve candidate articles from OpenAlex with a keyword query and,
    optionally, an embedding-based semantic query.
 2. Score every candidate's similarity to the manuscript with TF-IDF cosine
    similarity over title + abstract, blended with OpenAlex's semantic score.
 3. Take the top-N most similar articles and sum similarities per journal
    (and per author). Journals that publish *many closely related* papers win,
    rather than journals with one lucky hit.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from .text import TfidfSimilarity, rebuild_abstract

TOP_ARTICLES_FOR_AGGREGATION = 100
TFIDF_WEIGHT = 0.6
SEMANTIC_WEIGHT = 0.4


@dataclass
class Article:
    id: str
    title: str
    abstract: str
    year: int | None
    doi: str | None
    cited_by: int
    source: dict[str, Any] | None
    authors: list[dict[str, Any]]
    semantic_score: float | None = None
    keyword_hit: bool = False
    similarity: float = 0.0
    tfidf: float = 0.0

    def public(self) -> dict[str, Any]:
        src = self.source or {}
        return {
            "id": self.id,
            "title": self.title,
            "year": self.year,
            "doi": self.doi,
            "url": self.doi or self.id,
            "cited_by": self.cited_by,
            "journal": src.get("display_name"),
            "journal_id": src.get("id"),
            "authors": [a["name"] for a in self.authors[:6]],
            "more_authors": max(len(self.authors) - 6, 0),
            "similarity": round(self.similarity, 4),
        }


def _to_article(work: dict[str, Any]) -> Article | None:
    title = (work.get("title") or "").strip()
    if not title or not work.get("id"):
        return None
    loc = work.get("primary_location") or {}
    authors = []
    for a in work.get("authorships") or []:
        author = a.get("author") or {}
        if not author.get("id"):
            continue
        insts = [i.get("display_name") for i in a.get("institutions") or [] if i.get("display_name")]
        authors.append(
            {"id": author["id"], "name": author.get("display_name") or "Unknown", "inst": insts[:1]}
        )
    return Article(
        id=work["id"],
        title=title,
        abstract=rebuild_abstract(work.get("abstract_inverted_index")),
        year=work.get("publication_year"),
        doi=work.get("doi"),
        cited_by=work.get("cited_by_count") or 0,
        source=loc.get("source"),
        authors=authors,
    )


def merge_candidates(keyword_works: list[dict], semantic_works: list[dict]) -> list[Article]:
    """De-duplicate works from both searches, keeping the semantic score when present."""
    by_id: dict[str, Article] = {}
    max_sem = max((w.get("relevance_score") or 0.0 for w in semantic_works), default=0.0) or 1.0
    for w in semantic_works:
        art = _to_article(w)
        if art:
            art.semantic_score = (w.get("relevance_score") or 0.0) / max_sem
            by_id[art.id] = art
    for w in keyword_works:
        if w.get("id") in by_id:
            by_id[w["id"]].keyword_hit = True
            continue
        art = _to_article(w)
        if art:
            art.keyword_hit = True
            by_id[art.id] = art
    return list(by_id.values())


def score_articles(query_text: str, articles: list[Article]) -> list[Article]:
    if not articles:
        return []
    model = TfidfSimilarity(f"{a.title}. {a.title}. {a.abstract}" for a in articles)
    raw = model.query(query_text)
    top = max(raw) or 1.0
    use_semantic = any(a.semantic_score is not None for a in articles)
    for art, sim in zip(articles, raw):
        art.tfidf = sim
        tfidf_norm = sim / top
        if use_semantic:
            sem = art.semantic_score or 0.0
            art.similarity = TFIDF_WEIGHT * tfidf_norm + SEMANTIC_WEIGHT * sem
        else:
            art.similarity = tfidf_norm
    return sorted(articles, key=lambda a: a.similarity, reverse=True)


@dataclass
class JournalCandidate:
    source: dict[str, Any]
    score: float = 0.0
    articles: list[Article] = field(default_factory=list)


def aggregate_journals(ranked: list[Article]) -> list[JournalCandidate]:
    journals: dict[str, JournalCandidate] = {}
    for art in ranked[:TOP_ARTICLES_FOR_AGGREGATION]:
        src = art.source or {}
        sid = src.get("id")
        if not sid or src.get("type") not in (None, "journal"):
            continue
        cand = journals.setdefault(sid, JournalCandidate(source=src))
        cand.score += art.similarity
        cand.articles.append(art)
    return sorted(journals.values(), key=lambda j: j.score, reverse=True)


def aggregate_authors(ranked: list[Article], limit: int = 25) -> list[dict[str, Any]]:
    scores: dict[str, float] = defaultdict(float)
    info: dict[str, dict[str, Any]] = {}
    papers: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for art in ranked[:TOP_ARTICLES_FOR_AGGREGATION]:
        for a in art.authors:
            scores[a["id"]] += art.similarity
            info.setdefault(a["id"], a)
            if len(papers[a["id"]]) < 5:
                papers[a["id"]].append({"title": art.title, "url": art.doi or art.id, "year": art.year})
    if not scores:
        return []
    top = max(scores.values())
    out = []
    for aid, sc in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:limit]:
        a = info[aid]
        out.append(
            {
                "id": aid,
                "name": a["name"],
                "institution": a["inst"][0] if a["inst"] else None,
                "score": round(100 * sc / top, 1),
                "articles": papers[aid],
            }
        )
    return out

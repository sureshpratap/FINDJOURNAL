"""JournalMatch — find authentic Scopus / SCIE journals for a manuscript."""

__version__ = "1.0.0"

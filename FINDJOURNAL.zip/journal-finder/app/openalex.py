"""Thin async client for the parts of the OpenAlex API this app needs.

Cost notes (OpenAlex usage-based pricing, free key = $1/day):
  * keyword search  (?search=)          ~ $0.001 per call
  * semantic search (?search.semantic=) ~ $0.01  per call
  * list/filter (sources by ID)         ~ $0.0001 per call
One manuscript lookup = 1 keyword + 1 semantic + 1 source call ≈ $0.011.
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Any

import httpx

from .config import Settings

log = logging.getLogger(__name__)

WORK_FIELDS = ",".join(
    [
        "id",
        "doi",
        "title",
        "publication_year",
        "relevance_score",
        "abstract_inverted_index",
        "primary_location",
        "authorships",
        "cited_by_count",
        "type",
    ]
)

SOURCE_FIELDS = ",".join(
    [
        "id",
        "display_name",
        "issn_l",
        "issn",
        "host_organization_name",
        "homepage_url",
        "is_oa",
        "is_in_doaj",
        "apc_usd",
        "summary_stats",
        "works_count",
        "type",
        "country_code",
    ]
)

SEMANTIC_MAX_CHARS = 2000


class OpenAlexError(RuntimeError):
    pass


class OpenAlexClient:
    def __init__(self, settings: Settings, client: httpx.AsyncClient | None = None):
        self.settings = settings
        self._client = client or httpx.AsyncClient(
            base_url=settings.openalex_base_url,
            timeout=settings.request_timeout,
            headers={"User-Agent": "JournalMatch/1.0 (+https://github.com/)"},
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    def _params(self, extra: dict[str, Any]) -> dict[str, Any]:
        params = dict(extra)
        if self.settings.openalex_api_key:
            params["api_key"] = self.settings.openalex_api_key
        if self.settings.contact_email:
            params["mailto"] = self.settings.contact_email
        return params

    async def _get(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        try:
            resp = await self._client.get(path, params=self._params(params))
        except httpx.HTTPError as exc:
            raise OpenAlexError(f"Could not reach OpenAlex: {exc}") from exc
        if resp.status_code in (401, 403):
            raise OpenAlexError("OpenAlex rejected the API key. Check OPENALEX_API_KEY.")
        if resp.status_code in (409, 429):
            raise OpenAlexError(
                "OpenAlex daily credit limit reached. Try again tomorrow or add a key."
            )
        if resp.status_code >= 400:
            raise OpenAlexError(f"OpenAlex error {resp.status_code}: {resp.text[:200]}")
        return resp.json()

    @staticmethod
    def build_filter(years: int, open_access: str) -> str:
        parts = [
            "type:article|review",
            "primary_location.source.type:journal",
        ]
        if years > 0:
            parts.append(f"from_publication_date:{date.today().year - years + 1}-01-01")
        if open_access == "only":
            parts.append("primary_location.source.is_oa:true")
        elif open_access == "exclude":
            parts.append("primary_location.source.is_oa:false")
        return ",".join(parts)

    async def keyword_search(self, query: str, flt: str, per_page: int = 100) -> list[dict]:
        data = await self._get(
            "/works",
            {"search": query, "filter": flt, "per_page": per_page, "select": WORK_FIELDS},
        )
        return data.get("results", [])

    async def semantic_search(self, text: str, flt: str) -> list[dict]:
        data = await self._get(
            "/works",
            {
                "search.semantic": text[:SEMANTIC_MAX_CHARS],
                "filter": flt,
                "per_page": 50,
                "select": WORK_FIELDS,
            },
        )
        return data.get("results", [])

    async def sources(self, source_ids: list[str]) -> dict[str, dict]:
        """Fetch source (journal) details for up to 100 OpenAlex source IDs in one call."""
        short = [s.rsplit("/", 1)[-1] for s in source_ids if s][:100]
        if not short:
            return {}
        data = await self._get(
            "/sources",
            {"filter": "openalex:" + "|".join(short), "per_page": 100, "select": SOURCE_FIELDS},
        )
        return {s["id"]: s for s in data.get("results", [])}

/* JournalMatch frontend — plain JavaScript, no build step. */
(() => {
  "use strict";

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  const EXAMPLE = {
    title: "Sliding wear and thermal cycling behaviour of HVOF-sprayed functionally graded NiCrAlY/Al2O3 coatings for internal combustion engine pistons",
    abstract:
      "Piston crowns in high-output diesel engines face combined thermal fatigue and sliding wear. " +
      "In this work, functionally graded coatings with a NiCrAlY bond coat and three graded NiCrAlY/Al2O3 interlayers were deposited on aluminium alloy substrates by high-velocity oxy-fuel (HVOF) spraying. " +
      "Coating microstructure, porosity and phase composition were characterised by SEM, EDS and XRD, and microhardness and adhesion strength were measured. " +
      "Pin-on-disc sliding wear tests were performed at room temperature and 300 °C, and thermal cycling tests between 25 °C and 600 °C were used to assess spallation resistance. " +
      "The graded coatings showed lower porosity, 38% lower specific wear rate and more than twice the thermal cycling life of a conventional duplex coating, which is attributed to the reduced thermal expansion mismatch across the graded interlayers.",
  };

  const state = { data: null, tab: "journals", sort: "score", status: null };

  // ---------------------------------------------------------------- helpers
  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const safeUrl = (u) => (/^https?:\/\//i.test(u || "") ? u : null);
  const fmt = (n, digits = 0) =>
    n === null || n === undefined || Number.isNaN(n) ? "—" : Number(n).toLocaleString(undefined, { maximumFractionDigits: digits });

  async function api(path, options = {}) {
    const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...options });
    let body = null;
    try { body = await res.json(); } catch { /* non-JSON */ }
    if (!res.ok) {
      let msg = body && body.detail;
      if (Array.isArray(msg)) msg = msg.map((d) => d.msg.replace(/^Value error, /, "")).join(" ");
      throw new Error(msg || `Request failed (${res.status})`);
    }
    return body;
  }

  function setStatus(html, isError = false) {
    const el = $("#status");
    el.innerHTML = html;
    el.classList.toggle("error", isError);
  }

  // ---------------------------------------------------------------- views
  function showView(name) {
    $$(".view").forEach((v) => (v.hidden = v.id !== `view-${name}`));
    $$(".nav-link").forEach((b) => b.classList.toggle("is-active", b.dataset.view === name));
    window.scrollTo({ top: 0 });
  }
  $$(".nav-link").forEach((b) => b.addEventListener("click", () => showView(b.dataset.view)));

  // ---------------------------------------------------------------- server status
  async function loadStatus() {
    try {
      const s = await api("/api/status");
      state.status = s;
      const banner = $("#index-banner");
      const msgs = [];
      if (!s.index.loaded) {
        msgs.push("Journal lists are not loaded on this server yet. Suggestions will work, but Scopus/SCIE status cannot be verified.");
      } else if (!s.index.counts.scopus || !s.index.counts.SCIE) {
        msgs.push(`Only partial lists are loaded (${!s.index.counts.scopus ? "no Scopus list" : "no SCIE list"}).`);
      }
      if (!s.openalex_key_configured) msgs.push("No OpenAlex API key configured — only a few searches per day are possible.");
      banner.textContent = msgs.join(" ");
      banner.hidden = msgs.length === 0;
      if (!s.semantic_available) {
        $("#semantic").checked = false;
        $("#semantic").disabled = true;
        $("#semantic-wrap").classList.add("muted");
      }
      if (s.index.loaded) {
        const c = s.index.counts;
        $("#about-index").textContent =
          `Lists loaded on this server: ${fmt(c.scopus)} Scopus titles (${fmt(c.scopus_discontinued)} discontinued), ` +
          `${fmt(c.SCIE)} SCIE journals${c.ESCI ? `, ${fmt(c.ESCI)} ESCI journals` : ""}. Built ${new Date(s.index.built_at).toLocaleDateString()}.`;
      }
    } catch { /* status is informational only */ }
  }

  // ---------------------------------------------------------------- search form
  const titleEl = $("#title");
  const abstractEl = $("#abstract");
  const updateCount = () => ($("#char-count").textContent = `${abstractEl.value.length} / 12000`);
  abstractEl.addEventListener("input", updateCount);

  $("#example-btn").addEventListener("click", () => {
    titleEl.value = EXAMPLE.title;
    abstractEl.value = EXAMPLE.abstract;
    updateCount();
  });
  $("#search-form").addEventListener("reset", () => {
    setTimeout(updateCount, 0);
    $("#results").hidden = true;
    setStatus("");
  });

  $("#search-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      title: titleEl.value.trim(),
      abstract: abstractEl.value.trim(),
      years: Number($("#years").value),
      open_access: $("#open_access").value,
      indexing: $("#indexing").value,
      semantic: $("#semantic").checked,
    };
    if ((payload.title + payload.abstract).length < 20) {
      setStatus("Please paste a title and/or abstract (at least 20 characters).", true);
      return;
    }
    const btn = $("#submit-btn");
    btn.disabled = true;
    setStatus('<span class="spinner"></span>Finding similar papers and checking journal indexing… this takes 5–15 seconds.');
    try {
      state.data = await api("/api/suggest", { method: "POST", body: JSON.stringify(payload) });
      setStatus("");
      renderResults();
      $("#results").scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (err) {
      setStatus(esc(err.message), true);
      $("#results").hidden = true;
    } finally {
      btn.disabled = false;
    }
  });

  // ---------------------------------------------------------------- tabs & sort
  $$(".tab").forEach((t) =>
    t.addEventListener("click", () => {
      state.tab = t.dataset.tab;
      $$(".tab").forEach((x) => x.classList.toggle("is-active", x === t));
      $$(".tab-panel").forEach((p) => (p.hidden = p.id !== `tab-${state.tab}`));
      $("#sort-wrap").hidden = state.tab !== "journals";
    })
  );
  $("#sort").addEventListener("change", (e) => {
    state.sort = e.target.value;
    renderJournals();
  });

  // ---------------------------------------------------------------- rendering
  function renderResults() {
    const d = state.data;
    $("#results").hidden = false;
    $("#count-journals").textContent = `(${d.journals.length})`;
    $("#count-articles").textContent = `(${d.articles.length})`;
    $("#count-authors").textContent = `(${d.authors.length})`;
    $("#keywords").innerHTML =
      "Matched on: " + d.keywords.map((k) => `<span class="kw">${esc(k)}</span>`).join("") +
      ` <span class="muted">· ${d.stats.candidates} candidate papers compared${d.stats.semantic_used ? " (keyword + semantic)" : ""}</span>`;
    const warnings = [...d.warnings];
    if (d.hidden_by_filter > 0) {
      warnings.push(`${d.hidden_by_filter} other matching journal(s) were hidden because they are not in the selected index. Choose “Show all” in Search options to see them.`);
    }
    $("#warnings").innerHTML = warnings.map((w) => `<div class="warning">${esc(w)}</div>`).join("");
    renderJournals();
    renderArticles();
    renderAuthors();
  }

  function indexBadges(ix, extra = {}) {
    const b = [];
    if (ix.scopus) b.push('<span class="badge b-scopus" title="Active title in the Scopus Source Title List">✓ Scopus</span>');
    if (ix.scie) b.push('<span class="badge b-scie" title="Science Citation Index Expanded (Web of Science)">✓ SCIE</span>');
    (ix.wos_indexes || []).filter((x) => x !== "SCIE").forEach((x) =>
      b.push(`<span class="badge b-esci" title="${x === "ESCI" ? "Emerging Sources Citation Index — not SCIE" : "Web of Science"}">${esc(x)}</span>`)
    );
    if (ix.scopus_discontinued)
      b.push(`<span class="badge b-warn" title="${esc(ix.scopus_reason || "Coverage discontinued by Scopus")}">⚠ Scopus discontinued</span>`);
    else if (ix.scopus_inactive) b.push('<span class="badge b-warn" title="Listed as Inactive in Scopus">Scopus inactive</span>');
    if (!ix.matched && extra.indexLoaded) b.push('<span class="badge b-none">Not found in Scopus/WoS lists</span>');
    if (!extra.indexLoaded) b.push('<span class="badge b-none">Indexing not verified</span>');
    if (extra.in_doaj) b.push('<span class="badge b-oa" title="Listed in the Directory of Open Access Journals">DOAJ</span>');
    else if (extra.is_oa) b.push('<span class="badge b-oa">Open access</span>');
    return b.join("");
  }

  function verifyLinks(ix, issns) {
    const links = [];
    if (ix.scopus_id) links.push(`<a class="btn btn-ghost btn-small" target="_blank" rel="noopener" href="https://www.scopus.com/sourceid/${encodeURIComponent(ix.scopus_id)}">Scopus page ↗</a>`);
    const issn = (ix.index_issns && ix.index_issns[0]) || issns[0];
    if (issn) links.push(`<a class="btn btn-ghost btn-small" target="_blank" rel="noopener" href="https://mjl.clarivate.com/search-results?issn=${encodeURIComponent(issn)}">Master Journal List ↗</a>`);
    return links.join("");
  }

  function renderJournals() {
    const d = state.data;
    const indexLoaded = d.stats.index_loaded;
    const list = [...d.journals];
    if (state.sort !== "score") list.sort((a, b) => (b[state.sort] ?? -1) - (a[state.sort] ?? -1));
    if (!list.length) {
      $("#tab-journals").innerHTML = '<div class="card empty">No journals in the selected index matched. Try “Show all”, a longer time window, or a fuller abstract.</div>';
      return;
    }
    $("#tab-journals").innerHTML = list
      .map((j, i) => {
        const ix = j.indexing;
        const subjects = (ix.wos_categories && ix.wos_categories.length ? ix.wos_categories : []).slice(0, 4);
        const homepage = safeUrl(j.homepage);
        return `
        <article class="card journal">
          <div class="rank">${i + 1}</div>
          <div>
            <h3 class="j-name">${esc(j.name)}</h3>
            <div class="j-meta">${esc(j.publisher || "Publisher unknown")}${j.issns.length ? " · ISSN " + j.issns.map(esc).join(", ") : ""}${j.country ? " · " + esc(j.country) : ""}</div>
            <div class="score-row">
              <div class="bar" aria-hidden="true"><span style="width:${Math.max(4, j.score)}%"></span></div>
              <span class="score-text"><b>${fmt(j.score)}</b> match · ${j.n_similar} similar article${j.n_similar === 1 ? "" : "s"}</span>
            </div>
            <div class="badges">${indexBadges(ix, { indexLoaded, in_doaj: j.in_doaj, is_oa: j.is_oa })}</div>
            <div class="metrics">
              <span><b>${fmt(j.h_index)}</b>h-index</span>
              <span><b>${fmt(j.mean_citedness_2yr, 2)}</b>2-yr mean citedness</span>
              <span><b>${j.apc_usd ? "$" + fmt(j.apc_usd) : j.is_oa ? "—" : "None listed"}</b>APC (USD)</span>
            </div>
            ${subjects.length ? `<div class="subjects">WoS categories: ${subjects.map(esc).join(" · ")}</div>` : ""}
            <div class="actions">
              <button class="btn btn-ghost btn-small" data-toggle="sim-${i}">Show similar articles</button>
              ${verifyLinks(ix, j.issns)}
              ${homepage ? `<a class="btn btn-ghost btn-small" target="_blank" rel="noopener nofollow" href="${esc(homepage)}">Journal website ↗</a><span class="homepage-note">(from OpenAlex — confirm it matches the Scopus/MJL page)</span>` : ""}
            </div>
            <ul class="similar" id="sim-${i}" hidden>
              ${j.articles.map((a) => `<li><a href="${esc(safeUrl(a.url) || "#")}" target="_blank" rel="noopener">${esc(a.title)}</a> <span class="sim">${a.year || ""} · similarity ${fmt(a.similarity * 100)}%</span></li>`).join("")}
            </ul>
          </div>
        </article>`;
      })
      .join("");
    $$("#tab-journals [data-toggle]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const ul = document.getElementById(btn.dataset.toggle);
        ul.hidden = !ul.hidden;
        btn.textContent = ul.hidden ? "Show similar articles" : "Hide similar articles";
      })
    );
  }

  function renderArticles() {
    const arts = state.data.articles;
    $("#tab-articles").innerHTML = arts.length
      ? arts
          .map(
            (a) => `
        <div class="card article">
          <div class="article-title"><a href="${esc(safeUrl(a.url) || "#")}" target="_blank" rel="noopener">${esc(a.title)}</a></div>
          <div class="article-meta">${esc(a.authors.join(", "))}${a.more_authors ? ` +${a.more_authors}` : ""}</div>
          <div class="article-meta"><em>${esc(a.journal || "")}</em> ${a.year || ""} · cited ${fmt(a.cited_by)} · similarity ${fmt(a.similarity * 100)}%</div>
        </div>`
          )
          .join("")
      : '<div class="card empty">No articles.</div>';
  }

  function renderAuthors() {
    const authors = state.data.authors;
    $("#tab-authors").innerHTML = authors.length
      ? '<p class="muted">Researchers who publish closest to your topic. Useful when a journal asks you to suggest reviewers (check for conflicts of interest first).</p>' +
        authors
          .map(
            (a) => `
        <div class="card author">
          <div class="article-title"><a href="${esc(a.id)}" target="_blank" rel="noopener">${esc(a.name)}</a> <span class="muted">· score ${fmt(a.score)}</span></div>
          <div class="article-meta">${esc(a.institution || "Institution unknown")}</div>
          <div class="article-meta">${a.articles.map((p) => `<a href="${esc(safeUrl(p.url) || "#")}" target="_blank" rel="noopener">${esc(p.title)}</a> (${p.year || "n.d."})`).join("<br>")}</div>
        </div>`
          )
          .join("")
      : '<div class="card empty">No authors.</div>';
  }

  // ---------------------------------------------------------------- verify view
  $("#verify-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const issn = $("#verify-issn").value.trim();
    const out = $("#verify-result");
    if (!issn) return;
    out.innerHTML = '<p class="status"><span class="spinner"></span>Checking…</p>';
    try {
      const r = await api(`/api/journal/${encodeURIComponent(issn)}`);
      let cls = "neutral", head;
      if (!r.index_loaded) head = "Lists not loaded on this server";
      else if (r.scopus_discontinued) { cls = "bad"; head = "Discontinued in Scopus — be careful"; }
      else if (r.verified) { cls = "ok"; head = `Indexed in ${[r.scopus && "Scopus", r.scie && "SCIE"].filter(Boolean).join(" and ")}`; }
      else if (r.matched) { cls = "neutral"; head = `Listed, but not in Scopus or SCIE${r.wos_indexes.length ? " (" + r.wos_indexes.join(", ") + ")" : ""}`; }
      else { cls = "bad"; head = "Not found in the Scopus or Web of Science lists"; }
      out.innerHTML = `
        <div class="card verdict ${cls}">
          <h2>${esc(head)}</h2>
          ${r.index_title ? `<div><strong>${esc(r.index_title)}</strong></div>` : ""}
          <div class="badges" style="margin-top:10px">${indexBadges(r, { indexLoaded: r.index_loaded })}</div>
          <dl>
            <dt>ISSN checked</dt><dd>${esc(r.issn)} ${r.checksum_valid ? "" : '<span class="badge b-warn">invalid check digit</span>'}</dd>
            ${r.index_issns.length ? `<dt>ISSNs on record</dt><dd>${r.index_issns.map(esc).join(", ")}</dd>` : ""}
            ${r.scopus_reason ? `<dt>Scopus note</dt><dd>${esc(r.scopus_reason)}</dd>` : ""}
            ${r.wos_categories.length ? `<dt>WoS categories</dt><dd>${r.wos_categories.map(esc).join(" · ")}</dd>` : ""}
          </dl>
          <div class="actions">${verifyLinks(r, [r.issn])}</div>
          <p class="muted" style="font-size:13px;margin-bottom:0">A matching ISSN does not prove a website is genuine. Hijacked journals copy real ISSNs. Reach the journal through the official Scopus or Master Journal List page.</p>
        </div>`;
    } catch (err) {
      out.innerHTML = `<p class="status error">${esc(err.message)}</p>`;
    }
  });

  loadStatus();
})();
